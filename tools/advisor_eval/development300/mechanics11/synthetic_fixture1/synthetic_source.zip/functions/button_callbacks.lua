G.FUNCS.exit_overlay_menu = function(e) if e then return e end end
G.FUNCS.overlay_menu = function(e) if e then return e end end
G.FUNCS.start_run = function(e) if e then return e end end
G.FUNCS.go_to_menu = function(e) if e then return e end end