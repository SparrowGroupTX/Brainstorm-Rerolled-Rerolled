"""Agent implementations (future)."""
